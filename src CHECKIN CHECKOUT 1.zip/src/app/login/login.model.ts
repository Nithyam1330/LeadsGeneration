export class Login {
    username: string;
    password: string;
}