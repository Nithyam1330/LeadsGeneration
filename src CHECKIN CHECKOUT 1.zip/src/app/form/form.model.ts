export class FormModel {
    employeeName: string;
    source: string;
    destination: string;
    customerName: string;
    bookingDate: any;
    customerContact: any;
    travelDate: any;
    Passengers:any;
    customerEmail: string;
    remark: string;
    product: string;
    key?: any;
}
