export class FormCompanyModel {
    date: any;
    employeeName: string;
    companyName: string;
    concernPerson: string;
    contact: any;
    email: string;
    conversationDone:string;
    followup: any;
    remarks: string;
    key?: any;
}
