export enum URLS {
    LEADS_CREATOR = '/list/',
    CORPORATE= '/listCompany/',
    REGISTRATION= '/registration/',
    LOGINTIME= '/checkInOut/',
}

