export class Profile {
    id: string;
    oldpassword: string;
    password: string;
    confirmPassword: string;
}
