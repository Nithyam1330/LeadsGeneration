export class CheckInOut {
    username: string;
    checkInTime: string;
    checkOutTime: string;
}